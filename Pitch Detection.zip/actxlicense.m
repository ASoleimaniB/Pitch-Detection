function lic = actxlicense(progid)

if strcmpi(progid, 'KoanBox.KoanControl.1')
lic = 'KoanControl license';
return;
end
